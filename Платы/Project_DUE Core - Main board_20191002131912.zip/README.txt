Motherboard for Arduino DUE Core - main board
Additional boards:
1. W5500 Lite (Network)
2. ZS_042 (Clock DS3231, 32K EEPROM)
3. Micro SD card adapter (5V)
4. DS2482 I2C board

To do:
1. SPI memory параллельно SD_5V
2. 3.3V pins out
3. светодиоды для индикации Relay out
4. REL5 -> 34 pin DUE (D31)
5. Конденсаторы входные -> корпус 1206
6. Надписи у разъемов снизу
7. Для переменных резисторов увеличить площадки
8. SD-CS2 перенести на D22, а D52/D62 использовать как Serial4            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。